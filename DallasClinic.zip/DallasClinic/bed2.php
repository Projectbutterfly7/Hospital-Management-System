<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
// SQL query to fetch data from your table
$sql = "SELECT bedid, department, status FROM room";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Display Data</title>
    <style>
        table {
            width: 50%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>
<body>

<h2>Data from Database</h2>

<table>
    <tr>
        <th>Bed ID</th>
        <th>Department</th>
        <th>Status</th>
    </tr>
    <?php
    // Check if there are results
    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["bedid"] . "</td>";
            echo "<td>" . $row["department"] . "</td>";
            echo "<td>" . $row["status"] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No data found</td></tr>";
    }
    // Close connection
    $conn->close();
    ?>
</table>
<?php

        
          echo "
          <a href='bed.php' class='btn btn-success'>Edit</a>";
        
      
?>
</body>
</html>
