
<?php require_once('check_login.php');?>
<?php include('head.php');?>
<?php include('header.php');?>
<?php include('sidebar.php');?>
<?php include('connect.php');?>

<?php


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
// SQL query to fetch data from your table
$sql = "SELECT bedid, department, status FROM room";
$result = $conn->query($sql);
?>
 










<div class="pcoded-content">
<div class="pcoded-inner-content">

<div class="main-body">
<div class="page-wrapper">

<div class="page-header">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<div class="d-inline">
<h4>Bed Details</h4>

</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">
<ul class="breadcrumb-title">
<li class="breadcrumb-item">
<a href="index.php"> <i class="feather icon-home"></i> </a>
</li>
<li class="breadcrumb-item"><a>Bed Details</a>
</li>
<li class="breadcrumb-item"><a href="view-appointments-approved.php">Bed Details</a>
</li>
</ul>
</div>
</div>
</div>
</div>

<div class="page-body">

<div class="card">
<div class="card-header">
    <div class="col-sm-10">
    </div>
<!-- <h5>DOM/Jquery</h5>
<span>Events assigned to the table can be exceptionally useful for user interaction, however you must be aware that DataTables will add and remove rows from the DOM as they are needed (i.e. when paging only the visible elements are actually available in the DOM). As such, this can lead to the odd hiccup when working with events.</span> -->
</div>
<div class="card-block">
<div class="table-responsive dt-responsive">
<table id="dom-jqry" class="table table-striped table-bordered nowrap">
<thead>
<tr>
    <th>Bed Id</th>
    
    <th>Department</th>
    
    <th>Status</th>
    
</tr>
</thead>
<tbody>
<?php
    // Check if there are results
    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["bedid"] . "</td>";
            echo "<td>" . $row["department"] . "</td>";
            echo "<td>" . $row["status"]. "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No data found</td></tr>";
    }
    // Close connection
    $conn->close();
    ?>
</tbody> 
<tfoot>
<tr>
<th>Bed Id</th>
    
    <th>Department</th>
    
    <th>Status</th> 
</tr>
</tfoot>
</table>
</div>
</div>
</div>

<?php

        
          echo "
          <a href='bed.php' class='btn btn-success'>Edit</a>";
        
      
?>





</div>

</div>
</div>

<div id="#">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php

        
          echo "
          <a href='bed.php' class='btn btn-success'>Edit</a>";
        
      
?>
<?php include('footer.php');?>
