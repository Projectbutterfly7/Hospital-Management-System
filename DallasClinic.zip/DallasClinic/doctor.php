<?php 
require_once('check_login.php');
include('head.php');
include('header.php');
include('sidebar.php');
include('connect.php');

if(isset($_POST['btn_submit'])) {
    $doctorname = mysqli_real_escape_string($conn, $_POST['doctorname']);
    $mobilenumber = mysqli_real_escape_string($conn, $_POST['mobilenumber']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $loginid = mysqli_real_escape_string($conn, $_POST['loginid']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $education = mysqli_real_escape_string($conn, $_POST['education']);
    $experience = mysqli_real_escape_string($conn, $_POST['experience']);
    $consultancy_charge = mysqli_real_escape_string($conn, $_POST['consultancy_charge']);

    if(isset($_GET['editid'])) {
        $sql = "UPDATE doctor SET doctorname=?, mobileno=?, departmentid=?, loginid=?, status=?, education=?, experience=?, consultancy_charge=? WHERE doctorid=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssi", $doctorname, $mobilenumber, $department, $loginid, $status, $education, $experience, $consultancy_charge, $_GET['editid']);
        $stmt->execute();
        if($stmt->affected_rows > 0) {
            echo "<script>alert('Doctor Record Updated Successfully'); location.href = 'view-doctor.php';</script>";
        } else {
            echo mysqli_error($conn);
        }   
    } else {
        if($_POST['password'] === $_POST['cnfirmpassword']) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $sql = "INSERT INTO doctor (doctorname, mobileno, departmentid, loginid, password, status, education, experience, consultancy_charge) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssss", $doctorname, $mobilenumber, $department, $loginid, $password, $status, $education, $experience, $consultancy_charge);
            $stmt->execute();
            if($stmt->affected_rows > 0) {
                echo "<script>alert('Doctor Record Inserted Successfully'); location.href = 'view-doctor.php';</script>";
            } else {
                echo mysqli_error($conn);
            }
        } else {
            echo "<script>alert('Password does not match');</script>";
        }
    }
}

if(isset($_GET['editid'])) {
    $sql="SELECT * FROM doctor WHERE doctorid=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_GET['editid']);
    $stmt->execute();
    $result = $stmt->get_result();
    $rsedit = $result->fetch_assoc();
}

?>

<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-header">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<div class="d-inline">
<h4>Doctor</h4>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">
<ul class="breadcrumb-title">
<li class="breadcrumb-item">
<a href="dashboard.php"> <i class="feather icon-home"></i> </a>
</li>
<li class="breadcrumb-item"><a>Doctor</a>
</li>
<li class="breadcrumb-item"><a href="add_user.php">Doctor</a>
</li>
</ul>
</div>
</div>
</div>
</div>

<div class="page-body">
<div class="row">
<div class="col-sm-12">

<div class="card">
<div class="card-header">
</div>
<div class="card-block">
<form id="main" method="post" action="">
    
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Doctor Name</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" name="doctorname" id="doctorname" placeholder="Enter name...." required=""  value="<?php echo isset($rsedit['doctorname']) ? $rsedit['doctorname'] : ''; ?>" >
        </div>

        <label class="col-sm-2 col-form-label">Mobile No</label>
        <div class="col-sm-4">
            <input type="number" class="form-control" name="mobilenumber" id="mobilenumber" placeholder="Enter mobile number...." required="" value="<?php echo isset($rsedit['mobileno']) ? $rsedit['mobileno'] : ''; ?>">
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Department</label>
        <div class="col-sm-4">
            <select class="form-control" name="department" id="department" required="">
                <option value="">-- Select One --</option>
                <?php
                    $sqldepartment= "SELECT * FROM department WHERE status='Active'";
                    $qsqldepartment = mysqli_query($conn,$sqldepartment);
                    while($rsdepartment=mysqli_fetch_array($qsqldepartment)) {
                        $selected = ($rsdepartment['departmentid'] == $rsedit['departmentid']) ? "selected" : "";
                        echo "<option value='".$rsdepartment['departmentid']."' $selected>".$rsdepartment['departmentname']."</option>";
                    }
                ?>
            </select>
        </div>

        <label class="col-sm-2 col-form-label">Login Id</label
        <div class="col-sm-4"></div>
            <input class="form-control" type="text" name="loginid" id="loginid" value="<?php echo isset($rsedit['loginid']) ? $rsedit['loginid'] : ''; ?>"/>
        </div>
    </div>

    <?php 
    if(!isset($_GET['editid'])) {
    ?>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-4">
            <input class="form-control" type="password" name="password" id="password" required/>
        </div>

        <label class="col-sm-2 col-form-label">Confirm Password</label>
        <div class="col-sm-4">
            <input class="form-control" type="password" name="cnfirmpassword" id="cnfirmpassword" required/>
            <span class="messages" id="confirm-pw" style="color: red;"></span>
        </div>
    </div>
    <?php } ?>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Education</label>
        <div class="col-sm-4">
            <input class="form-control" type="text" name="education" id="education" value="<?php echo isset($rsedit['education']) ? $rsedit['education'] : ''; ?>" />
        </div>

        <label class="col-sm-2 col-form-label">Experience</label>
        <div class="col-sm-4">
            <input class="form-control" type="text" name="experience" id="experience" value="<?php echo isset($rsedit['experience']) ? $rsedit['experience'] : ''; ?>"/>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Consultancy Charge</label>
        <div class="col-sm-4">
            <input class="form-control" type="text" name="consultancy_charge" id="consultancy_charge" value="<?php echo isset($rsedit['consultancy_charge']) ? $rsedit['consultancy_charge'] : ''; ?>"/>
        </div>        

        <label class="col-sm-2 col-form-label">Status</label>
        <div class="col-sm-4">
            <select name="status" id="status" class="form-control" required="">
                <option value="">-- Select One --</option>
                <option value="Active" <?php echo isset($rsedit['status']) && $rsedit['status'] == 'Active' ? 'selected' : ''; ?>>Active</option>
                <option value="Inactive" <?php echo isset($rsedit['status']) && $rsedit['status'] == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-2"></label>
        <div class="col-sm-10">
            <button type="submit" name="btn_submit" class="btn btn-primary m-b-0">Submit</button>
        </div>
    </div>

</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('footer.php');?>

<script type="text/javascript">
    $(document).ready(function() {
        // Validate password match
        $('#password, #cnfirmpassword').on('keyup', function () {
            if ($('#password').val() == $('#cnfirmpassword').val()) {
                $('#confirm-pw').html('').css('color', 'green');
            } else 
                $('#confirm-pw').html('Passwords do not match').css('color', 'red');
        });
    });
</script>
